import pickle

with open('pose_t.pkl', 'rb') as stream1:
    pose = pickle.load(stream1)

print(pose)

info = [1,23,3]
pickle.dump([1,2,3], open( "testpickle1.pkl", "wb" ))
pickle.dump(([1,2,3], info), open( "testpickle2.pkl", "wb" ))